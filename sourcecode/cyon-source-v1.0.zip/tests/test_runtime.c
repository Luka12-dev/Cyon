#include <stdio.h>

int main(void) {
    printf("runtime-test: OK\n");
    return 0;
}